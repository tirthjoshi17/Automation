#!/usr/bin/env python3
import requests
import json
import argparse
import yaml
import os
import sys

def get_auth_token(zabbix_url, zabbix_user, zabbix_pass):
    url = f"{zabbix_url}/api_jsonrpc.php"
    headers = {"Content-Type": "application/json"}
    payload = {
        'jsonrpc': "2.0",
        'method': "user.login",
        'params': {
            'user': zabbix_user,
            'password': zabbix_pass
        },
        'id': 1,
        'auth': None
    }

    try:
        response = requests.post(url, data=json.dumps(payload), headers=headers, timeout=10)
        response.raise_for_status()
        result = response.json()
        if "result" in result:
            return result["result"]
        else:
            print(f"Zabbix API login error: {result.get('error', {})}")
            return None
    except requests.exceptions.RequestException as e:
        print(f"HTTP request failed: {e}")
        return None
    except json.JSONDecodeError:
        print("Failed to decode JSON response from Zabbix API.")
        print(f"Raw response: {response.text}")
        return None

def create_user(zabbix_url, auth_token, username, password, role):
    roles = {
        'User role': 1,
        'Admin role': 2,
        'Super admin role': 3,
        'Guest role': 4
    }
    role_id = roles.get(role)
    if not role_id:
        print(f"Invalid role '{role}' for user '{username}'. Skipping.")
        return None

    url = f"{zabbix_url}/api_jsonrpc.php"
    headers = {"Content-Type": "application/json"}
    default_usrgrpid = "7"

    payload = {
        'jsonrpc': "2.0",
        'method': "user.create",
        'params': {
            'alias': username,
            'name': username,
            'surname': "User",
            'passwd': password,
            'usrgrps': [{'usrgrpid': default_usrgrpid}],
            'roleid': role_id
        },
        'auth': auth_token,
        'id': 2
    }

    response = requests.post(url, data=json.dumps(payload), headers=headers)
    try:
        result = response.json()
        if "result" in result:
            userid = result["result"]["userids"][0]
            print(f"✅ User '{username}' created successfully with role '{role}'.")
            return userid
        else:
            err = result.get("error", {}).get("data", "Unknown error")
            print(f"❌ Error creating user '{username}': {err}")
            return None
    except json.JSONDecodeError:
        print(f"❌ Failed to decode response when creating user '{username}'. Raw response: {response.text}")
        return None

def delete_user(zabbix_url, auth_token, userid):
    url = f"{zabbix_url}/api_jsonrpc.php"
    headers = {"Content-Type": "application/json"}
    payload = {
        'jsonrpc': "2.0",
        'method': "user.delete",
        'params': [userid],
        'auth': auth_token,
        'id': 3
    }
    response = requests.post(url, data=json.dumps(payload), headers=headers)
    try:
        result = response.json()
        if "result" in result:
            print(f"🗑️  User ID {userid} deleted successfully.")
            return True
        else:
            err = result.get("error", {}).get("data", "Unknown error")
            print(f"❌ Error deleting user ID {userid}: {err}")
            return False
    except json.JSONDecodeError:
        print(f"❌ Failed to decode response during user deletion. Raw response: {response.text}")
        return False

def logout(zabbix_url, auth_token):
    url = f"{zabbix_url}/api_jsonrpc.php"
    headers = {"Content-Type": "application/json"}
    payload = {
        'jsonrpc': "2.0",
        'method': "user.logout",
        'params': [],
        'auth': auth_token,
        'id': 4
    }
    try:
        response = requests.post(url, data=json.dumps(payload), headers=headers)
        print("🔓 Logged out of Zabbix API.")
    except Exception:
        print("⚠️ Logout failed.")

def load_config_from_yaml(file_path):
    try:
        with open(file_path, "r") as f:
            data = yaml.safe_load(f)
            zabbix_config = data.get("zabbix", {})
            users = data.get("users", [])
            return zabbix_config, users
    except Exception as e:
        print(f"❌ Failed to load YAML file '{file_path}': {e}")
        return {}, []

def parse_arguments():
    parser = argparse.ArgumentParser(description="Zabbix user manager from YAML")
    parser.add_argument("--yaml", default="users.yaml", help="Path to YAML file")
    parser.add_argument("--user_state", choices=["present", "absent"], default="present", help="user_state to perform")
    parser.add_argument("--userfile", default="/tmp/zabbix_created_users.json", help="Path to store created user IDs")
    return parser.parse_args()

def main():
    args = parse_arguments()
    zabbix_config, users = load_config_from_yaml(args.yaml)

    required_keys = ("url", "username", "password")
    if not all(k in zabbix_config for k in required_keys):
        print("❌ YAML is missing one of: url, username, password under 'zabbix'.")
        sys.exit(1)

    auth_token = get_auth_token(zabbix_config["url"], zabbix_config["username"], zabbix_config["password"])
    if not auth_token:
        sys.exit(1)

    if args.user_state == "present":
        if not users:
            print("⚠️ No users defined in YAML.")
            sys.exit(0)

        created_user_ids = []
        try:
            for user in users:
                username = user.get("name")
                password = user.get("password")
                role = user.get("zabbix_role")

                if not (username and password and role):
                    print(f"⚠️ Skipping incomplete user entry: {user}")
                    continue

                userid = create_user(zabbix_config["url"], auth_token, username, password, role)
                if userid:
                    created_user_ids.append(userid)
                else:
                    raise Exception(f"Failed to create user: {username}")

            with open(args.userfile, "w") as f:
                json.dump(created_user_ids, f)
            print(f"📁 User IDs saved to {args.userfile}")

        except Exception as e:
            print(f"\n⚠️ Error: {e}")
            print("🔁 Rolling back created users...")
            for uid in created_user_ids:
                delete_user(zabbix_config["url"], auth_token, uid)
            if os.path.exists(args.userfile):
                os.remove(args.userfile)
            sys.exit(1)

    elif args.user_state == "absent":
        if not os.path.exists(args.userfile):
            print(f"⚠️ No file at {args.userfile}. Nothing to absent.")
            sys.exit(0)

        with open(args.userfile, "r") as f:
            created_user_ids = json.load(f)
        for uid in created_user_ids:
            delete_user(zabbix_config["url"], auth_token, uid)

        os.remove(args.userfile)
        print(f"✅ absent complete. Deleted users from {args.userfile}.")

    logout(zabbix_config["url"], auth_token)

if __name__ == "__main__":
    main()
